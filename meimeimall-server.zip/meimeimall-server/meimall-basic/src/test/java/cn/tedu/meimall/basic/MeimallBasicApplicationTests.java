package cn.tedu.meimall.basic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MeimallBasicApplicationTests {

    @Test
    void contextLoads() {
    }

}
