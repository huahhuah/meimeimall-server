package cn.tedu.meimall.basic;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MeimallBasicApplication {

    public static void main(String[] args) {
        SpringApplication.run(MeimallBasicApplication.class, args);
    }

}
