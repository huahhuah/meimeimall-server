package cn.tedu.meimall.passport;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MeimallPassportApplication {

    public static void main(String[] args) {
        SpringApplication.run(MeimallPassportApplication.class, args);
    }

}
