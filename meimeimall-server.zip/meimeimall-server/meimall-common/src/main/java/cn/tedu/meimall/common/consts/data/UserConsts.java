package cn.tedu.meimall.common.consts.data;

/**
 * 用戶管理相關常量
 */
public interface UserConsts extends CommonConsts{
}
