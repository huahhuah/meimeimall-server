package cn.tedu.meimall.front.mall;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MeimallFrontMallApplication {

    public static void main(String[] args) {
        SpringApplication.run(MeimallFrontMallApplication.class, args);
    }

}
