package cn.tedu.meimall.front.content;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MeimallFrontContentApplication {

    public static void main(String[] args) {
        SpringApplication.run(MeimallFrontContentApplication.class, args);
    }

}
