package cn.tedu.meimall.front.content;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MeimallFrontContentApplicationTests {

    @Test
    void contextLoads() {
    }

}
